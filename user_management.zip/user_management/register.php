<?php
include 'db.php'; // Database connection

// Get JSON data from the request
$data = json_decode(file_get_contents("php://input"), true);

// Validate input
if (!isset($data['username'], $data['email'], $data['password'])) {
    echo json_encode(["status" => "error", "message" => "Invalid input data!"]);
    exit;
}

$username = $data['username'];
$email = $data['email'];
$password = $data['password'];

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Check if the username or email already exists using prepared statement
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
$stmt->bind_param("ss", $username, $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "Username or email already exists!"]);
} else {
    // Insert user using prepared statement
    $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $email, $hashed_password);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Sign-up successful!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error: " . $stmt->error]);
    }
}

$stmt->close();
$conn->close();
?>
