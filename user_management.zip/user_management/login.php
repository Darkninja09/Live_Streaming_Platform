<?php
// Connect to database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_management"; // Use your actual database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['username']) && isset($data['password'])) {
    $username = $data['username'];
    $password = $data['password'];

    // Query to check for the username and password in the database
    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User found, return success
        echo json_encode(["status" => "success", "message" => "Login successful"]);
    } else {
        // Invalid login credentials
        echo json_encode(["status" => "error", "message" => "Invalid username or password"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Username and password are required"]);
}

$conn->close();
?>