<?php
$host = "localhost";
$user = "root";
$pass = ""; // Set your MySQL password if you have one
$dbname = "user_management";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected successfully!";
}
?>
